--question3.sql: change the statement below.

SELECT *
FROM student;
